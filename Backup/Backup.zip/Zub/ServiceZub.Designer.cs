namespace vit.Zub
{
    /// <summary>
    /// �������� ����� (���������) �������
    /// </summary>
    partial class Zub
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        private void InitializeComponent()
        {
            // 
            // Zub
            // 
            this.ServiceName = "Zub";

        }

        #endregion
    }
}
